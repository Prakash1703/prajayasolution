<head>
   <link rel="stylesheet" href="<?php echo e(asset('/css/home-pagee166.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('/css/custom.css')); ?>">
   <title>Software Development Company - PrajayaSolutions</title>
   <link rel="icon" href="<?php echo e(asset('/images/favicon/favicon.ico')); ?>" type="image/x-icon" />
</head><?php /**PATH D:\prajaya\resources\views/layout/head.blade.php ENDPATH**/ ?>