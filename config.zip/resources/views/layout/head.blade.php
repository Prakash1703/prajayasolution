<head>
   <link rel="stylesheet" href="{{asset('/css/home-pagee166.css')}}">
   <link rel="stylesheet" href="{{asset('/css/custom.css')}}">
   <title>Software Development Company - PrajayaSolutions</title>
   <link rel="icon" href="{{asset('/images/favicon/favicon.ico')}}" type="image/x-icon" />
</head>