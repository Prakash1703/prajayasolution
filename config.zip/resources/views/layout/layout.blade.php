<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
       @include('layout.head')
    </head>
    <body>
    @include('layout.header')    
    @include('layout.footer')
    </body>
</html>
